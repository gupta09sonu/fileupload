const express = require('express');
const fileUpload = require('express-fileupload');
const requestIp = require('@supercharge/request-ip');
const path = require('path');
const app = express();
const port = 3000;
const host = '127.0.0.1';
const multer = require('multer');
var fName;

//file upload folder
const DIR = './uploads/';
const maxSize = 1 * 1024 * 1024;

// use fileupload middleware
// app.use(fileUpload());
app.use(express.static("./uploads"));

const storage = multer.diskStorage({
    destination:(req,file,cb)=>{
        cb(null,DIR);
    },
    filename: (req,file,cb)=>{
        const IP = requestIp.getClientIp(req);
        const fileName = Date.now() + "-" + IP + "-" + file.originalname ;
        cb(null,fileName);
    }
});

var upload = multer({
    storage: storage,
    // fileFilter: (req,file,cb)=>{
    //     if (file.mimetype == "image/png" || file.mimetype == "image/jpg" || file.mimetype == "image/jpeg") {
    //         cb(null, true);
    //       } else {
    //         cb(null, false);
    //         return cb(new Error('Only .png, .jpg and .jpeg format allowed!'));
    //       }
    // },
    // limits: { fileSize: maxSize }
}).single('file');

app.get('/',(req,res)=>{
    res.sendFile(__dirname + '/index.html');
});

app.post('/',(req,res)=>{

    var URL = 'http://localhost:3000/';
    // if(req.files){
    //     console.log(req.files);
    //     let file = req.files.file;
    //     let fileName = file.name;
    //     file.mv(DIR +file.name,(err,result)=>{
    //         if(err){
    //             res.send(err);
    //         } else{
    //             res.send({
    //                 success: true,
    //                 message: "File Upload Seccess!!!"
    //             });
    //         }
    //     });
    // }
    upload(req, res, function (err) {
        if (err instanceof multer.MulterError) {
          // A Multer error occurred when uploading.
          res.send(err)
        } else if (err) {
          // An unknown error occurred when uploading.
          res.send(err)
        }
        fname = req.file.filename;
        res.send(req.file.filename);
        
     
        // Everything went fine.
      })
});

app.get('/:path',(req,res)=>{
    console.log(req.params.path);
    var name = req.params.path;
    // console.log(path.join(__dirname,'uploads')+'/'+name);
    if(fname === name){
        res.download(path.join(__dirname,'uploads'+'/'+ name));
    }
    else{
        res.send({err: 'file name is incorrect'});
    }
});

app.listen(port,host,()=>{
    console.log(`server is listening at http://${host}:${port}`);
});